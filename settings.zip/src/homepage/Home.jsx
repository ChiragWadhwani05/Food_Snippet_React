
import './homepage.css';
import React from 'react';
import Navbar from '../navbar/Navbar.jsx';

function Home() {
  return <div className='home-main'>
    <h1>This Is Home</h1>
    
  </div>;
}

export default Home;