import React from 'react';
import {BrowserRouter, Routes, Route} from 'react-router-dom';
import Home from './homepage/Home.jsx';
import Navbar from './navbar/Navbar.jsx';
import Settings from "./settingspage/Settings.jsx";
import Footer from "./footer/Footer.jsx";
// import './global.css';
function App() {
    return(
        <BrowserRouter>
        <div className="app">
        <Navbar />
        <Routes >
            <Route path="/home" element={<Home />} />
            <Route path="/settings" element={<Settings />} />
            {/* <Route path="/liked-recipes" element={<LikedRecipes />} /> */}
        </Routes>
        <Footer />
        </div>
    </BrowserRouter>
    );
}
export default App;