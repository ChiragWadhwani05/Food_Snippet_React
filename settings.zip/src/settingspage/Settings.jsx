import React, { useState, useEffect } from 'react';
import './settings.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCheck } from '@fortawesome/free-solid-svg-icons';
function settings() {
    const [theme, setTheme] = useState("light");
    const [primaryColor, setPrimaryColor] = useState(0);
    
    const [settings, setSettings] = useState({
        '--background-color': '#fff',
        '--background-light': '#fff',
        '--shadow-color': 'rgba(0,0,0,0.2)',
        // '--primary-color': 'rgb(0, 200, 83)',
        '--text-color': '#0A0A0A',
        '--text-light': '#575757',
        '--font-size': '14px',
    });

    const themes = [
        {
        '--background-color': '#fff',
        '--background-light': '#fff',
        '--shadow-color': 'rgba(0,0,0,0.2)',
        // '--primary-color': 'rgb(0, 200, 83)',
        '--text-color': '#0A0A0A',
        '--text-light': '#575757',
        },
        {
        '--background-color': 'rgb(29,29,29)',
        '--background-light': 'rgb(77,77,77)',
        '--shadow-color': 'rgba(0,0,0,0.2)',
        // '--primary-color': 'rgb(0, 200, 83)',
        '--text-color': '#ffffff',
        '--text-light': '#eceaea',
        },
    ];
    const primaryColors = [
        'rgb(255, 0, 86)',
        'rgb(33, 150, 243)',
        'rgb(255, 193, 7)',
        'rgb(0, 200, 83)',
        'rgb(156, 39, 176)',
    ];
    useEffect(() => {
        const storedPrimaryColor = localStorage.getItem('primaryColor');
        const storedTheme = localStorage.getItem('theme');

    if (storedTheme) {
        setTheme(storedTheme);
    }

    if (storedPrimaryColor) {
        setPrimaryColor(parseInt(storedPrimaryColor));
    }

    const root = document.documentElement;
    for(let key in settings){
        root.style.setProperty(key, settings[key])
    };
    }, [settings]);


    const handleThemeSelection = (crrTheme) => {
        localStorage.setItem('theme', crrTheme === 0 ? 'light' : 'dark');
        const _theme = { ...themes[crrTheme] };
        setTheme(crrTheme === 0 ? 'light' : 'dark');
        let _settings = { ...settings };
        for (let key in _theme) {
        _settings[key] = _theme[key];
        }
        setSettings(_settings);
        
    };

    const handlePrimaryColorSelection = (key) => {
        const _color = primaryColors[key];
        let _settings = { ...settings };
        _settings['--primary-color'] = _color;
        setPrimaryColor(key);
        setSettings(_settings);
        localStorage.setItem('primaryColor', key);
    };

    
    return (
        <div className="settings-container">
        <h1 className="settings">Settings</h1>
        <div className="settings-options">
            <label htmlFor="preferred-theme" className="settings-label">
            Preferred Theme:
            </label>
            <div className="theme-options">
            <div
                className="theme light"
                onClick={() => handleThemeSelection(0)}
            >
                {(theme === 'light') && (
                <div className="settings-check">
                    <FontAwesomeIcon icon={faCheck} />
                </div>
                )}
            </div>
            <div
                className="theme dark"
                onClick={() => handleThemeSelection(1)}
            >
                {(theme === 'dark') && (
                <div className="settings-check">
                    <FontAwesomeIcon icon={faCheck} />
                </div>
                )}
            </div>
            </div>
            <div className="settings-options">
            <label htmlFor="primary-color" className="settings-label">
                Primary Color:
            </label>
            <div className="theme-options">
                {primaryColors.map((color, index) => (
                <div
                    className="theme"
                    style={{ backgroundColor: color }}
                    key={index} // Add a unique key for each item in the map
                    onClick={() => handlePrimaryColorSelection(index)}
                >
                    {index === primaryColor && (
                    <div className="settings-check">
                        <FontAwesomeIcon icon={faCheck} />
                    </div>
                    )}
                </div>
                ))}
            </div>
            </div>
        </div>
        </div>
    );
}

export default settings;
